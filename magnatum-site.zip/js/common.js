$(document).ready(function() {
	
	$(".togle_mnu").click(function() {
		$(this).toggleClass("on");
		$("header.header .top_header .header_nav").slideToggle();
	});
	
	$("#menu").on("click","a", function (event) {
        event.preventDefault();
        var id  = $(this).attr('href'),
            top = $(id).offset().top;
        $('body,html').animate({scrollTop: top}, 1000);
    });
	
	

});